Source version (included here, recommended because more stable):

This file comes from:

https://github.com/TriTriTheCuber/TFX/blob/main/tritrisim\_installer.py



1\. Install Python 3.13.4 or similar version from python.org

   - Make sure to check "Add Python to PATH" during install!



2\. Run dependencies.bat. This will install all the dependencies needed for the installer to function (dearpygui, requests)





3\. Run the installer:

   py tritrisim\_installer.py

   Or just run via running the file in the files.





If you have any issues, please see 'Info / Help me!'.



Executable version (UNSTABLE, EXPERIMENTAL):

https://github.com/TriTriTheCuber/TFX/blob/main/TriTriSim%20Installer.exe

**WARNING:** Despite being just a packaged version of the source installer (via pyinstaller), the executable version is much more unstable compared to the source version. It also gets flagged on VirusTotal, and this is a known behavior with PyInstaller packaged files. **This is why i recommend the python version.**

