**Requirements: Having read through README.MD, and having either the source or executable version of the installer prepared.**


Now that you have your installer up and running, here's how we can get TFX working for your simulator.



1. If after the installer loads, there are some windows telling you to select your community folder, this means that the installer couldn't detect your folder automatically. Simply use the directory windows to select the community folder for each sim. 
   If you do not own one of the simulators, clicking 'cancel' on the respective window will confirm that said simulator is not installed on your computer.
   
2. If you mess up while selecting your folders, do not panic. Close the installer, and find and delete the file named **community.txt**. If said file does not exist, or you have now deleted it, run the installer and select your community folders correctly.
   
3. **THIS IS IMPORTANT.** Now that you have confirmed that your community folder(s) have been set correctly, install the base package and material package for your simulator. **Don't worry if the materials take a while. They are 1.4gb straight from GitHub.**

4. Now, select any plane you would like to install TFX for with the buttons below the basepack / materialpack buttons.
   
5. You should be done! Fire up the sim and test.



**Recommended actions:**

Join the [discord server](https://discord.gg/g4bJ3nBmck) for support. This is an open beta after all, and there WILL be issues. If that hyperlink doesn't work, use this. https://discord.gg/g4bJ3nBmck

